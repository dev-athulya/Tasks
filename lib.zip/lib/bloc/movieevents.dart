abstract class MovieEvent {}

// This event is triggered when the user searches for movies

class SearchMovies extends MovieEvent {
  final String query;
  final int page;

  SearchMovies(this.query, {this.page = 1});
}

class ClearMovies extends MovieEvent {}

class LoadMoreMovies extends MovieEvent {}
