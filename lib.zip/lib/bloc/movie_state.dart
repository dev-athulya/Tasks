import 'package:task_assment/data/models/movies_model.dart';

abstract class MovieState {}

// The MovieState class is the base class for all states in the movie search feature.
// It defines the different states that the MovieBloc can be in during the movie search process.
class MovieInitial extends MovieState {}

class MovieLoading extends MovieState {}

class MovieLoaded extends MovieState {
  final List<Movie> movies;
  final bool hasReachedMax;

  MovieLoaded(this.movies, {this.hasReachedMax = false});
}

class MovieError extends MovieState {
  final String message;

  MovieError(this.message);
}
