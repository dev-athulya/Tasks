import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:task_assment/bloc/movieevents.dart';
import 'package:task_assment/data/models/movies_model.dart';
import 'package:task_assment/data/repo/movies_repo.dart';
import 'movie_state.dart';

class MovieBloc extends Bloc<MovieEvent, MovieState> {
  // The MovieBloc class is responsible for managing the state of the movie search feature.
  final MovieRepository repository;

  int currentPage = 1;
  String currentQuery = '';
  List<Movie> movies = [];
  bool isFetching = false;

  MovieBloc(this.repository) : super(MovieInitial()) {
    on<SearchMovies>((event, emit) async {
      if (event.page == 1) {
        emit(MovieLoading());
      }

      try {
        //The MovieBloc listens for the event and interacts with the MoviesRepository to fetch data.
        final newMovies = await repository.searchMovies(
          event.query,
          event.page,
        );

        if (event.page == 1) {
          movies = newMovies;
          currentQuery = event.query;
          currentPage = 1;
        } else {
          movies.addAll(newMovies);
        }

        emit(MovieLoaded(movies, hasReachedMax: newMovies.isEmpty));
        currentPage++;
      } catch (e) {
        emit(MovieError(e.toString()));
      }
    });

    on<ClearMovies>((event, emit) {
      // Clear the list of movies and reset the current page and query
      // This event is triggered when the user wants to clear the search results & starts a new search

      movies.clear();
      currentPage = 1;
      currentQuery = '';
      emit(MovieInitial());
    });

    on<LoadMoreMovies>((event, emit) async {
      if (state is MovieLoaded && !isFetching) {
        isFetching = true;

        try {
          final newMovies = await repository.searchMovies(
            currentQuery,
            currentPage,
          );

          if (newMovies.isNotEmpty) {
            movies.addAll(newMovies);
            emit(MovieLoaded(movies, hasReachedMax: newMovies.isEmpty));
            currentPage++;
          } else {
            // If no more movies are available, emit the loaded state with hasReachedMax set to true
            emit(MovieLoaded(movies, hasReachedMax: true));
          }
        } catch (e) {
          emit(MovieError('Failed to load more movies: $e'));
        } finally {
          isFetching = false;
        }
      }
    });
  }
}
