import 'package:flutter/material.dart';
import 'package:task_assment/data/models/movies_model.dart';

class MovieCard extends StatelessWidget {
  final Movie movie;
  final VoidCallback onTap;

  const MovieCard({Key? key, required this.movie, required this.onTap})
    : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading:
            movie.posterPath.isNotEmpty
                ? Image.network(movie.posterPath, width: 50, fit: BoxFit.cover)
                : Container(
                  width: 50,
                  height: 75,
                  color: Colors.grey,
                  child: const Icon(Icons.image_not_supported),
                ),
        title: Text(movie.title),
        subtitle: Text('Release: ${movie.releaseDate}'),
        onTap: onTap,
      ),
    );
  }
}
