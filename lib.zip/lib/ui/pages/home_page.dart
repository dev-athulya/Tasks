import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:task_assment/bloc/movie_state.dart';
import 'package:task_assment/bloc/moviebloc.dart';
import 'package:task_assment/bloc/movieevents.dart';
import 'package:task_assment/data/repo/movies_repo.dart';
import 'package:task_assment/ui/pages/movie_detail_page.dart';
import 'package:task_assment/ui/widgets/movie_card.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // Initialize the MovieBloc with the MovieRepository
  // This is where the MovieBloc is created and provided to the widget tree
  // The MovieBloc will handle the business logic and state management for the movie search feature
  // The MovieRepository is responsible for fetching movie data from the API

  final MovieBloc _movieBloc = MovieBloc(MovieRepository());
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  late FocusNode myFocusNode;

  @override
  void initState() {
    super.initState();
    myFocusNode = FocusNode();
    // Add a listener to the ScrollController to detect when the user scrolls to the bottom
    _scrollController.addListener(() {
      if (_scrollController.position.pixels >=
              _scrollController.position.maxScrollExtent &&
          !_movieBloc.isFetching) {
        _movieBloc.add(LoadMoreMovies()); // Trigger event to load more movies
      }
    });
  }

  @override
  void dispose() {
    myFocusNode.dispose();

    _scrollController.dispose();
    _searchController.dispose();
    _movieBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Movie Search')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              autofocus: true,
              focusNode: myFocusNode,
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search for movies...',
                border: OutlineInputBorder(),
                suffixIcon: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.search),
                      onPressed: () {
                        final query = _searchController.text.trim();
                        if (query.isNotEmpty) {
                          _movieBloc.add(SearchMovies(query));
                        }
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                        _movieBloc.add(ClearMovies());
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: BlocBuilder<MovieBloc, MovieState>(
              bloc: _movieBloc,
              builder: (context, state) {
                if (state is MovieInitial) {
                  return Center(child: Text('Start typing to search'));
                } else if (state is MovieLoading) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(),
                        SizedBox(height: 16),
                        Text('Loading movies...'),
                      ],
                    ),
                  );
                } else if (state is MovieLoaded) {
                  if (state.movies.isEmpty) {
                    return Center(child: Text('No movies found'));
                  }
                  return ListView.builder(
                    controller:
                        _scrollController, // Attach the ScrollController
                    itemCount:
                        state.hasReachedMax
                            ? state.movies.length
                            : state.movies.length +
                                1, // Add a loading indicator at the end
                    itemBuilder: (context, index) {
                      if (index >= state.movies.length) {
                        return Center(child: CircularProgressIndicator());
                      }
                      return MovieCard(
                        movie: state.movies[index],
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder:
                                  (context) => MovieDetailsPage(
                                    movie: state.movies[index],
                                  ),
                            ),
                          );
                        },
                      );
                    },
                  );
                } else if (state is MovieError) {
                  return Center(child: Text(state.message));
                }
                return Container();
              },
            ),
          ),
        ],
      ),
    );
  }
}
