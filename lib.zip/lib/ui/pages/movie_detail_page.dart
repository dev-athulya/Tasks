import 'package:flutter/material.dart';
import 'package:task_assment/data/models/movies_model.dart';

class MovieDetailsPage extends StatelessWidget {
  final Movie movie;

  const MovieDetailsPage({Key? key, required this.movie}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(movie.title)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child:
                  movie.posterPath != null
                      ? Image.network(
                        'https://image.tmdb.org/t/p/w500${movie.posterPath}',
                        height: 300,
                      )
                      : Container(height: 300, color: Colors.grey),
            ),
            const SizedBox(height: 20),
            Text(
              movie.title,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              'Release Date: ${movie.releaseDate}',
              style: TextStyle(color: Colors.grey[700]),
            ),
            const SizedBox(height: 20),
            Text(movie.overview, style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
