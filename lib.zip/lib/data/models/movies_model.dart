class Movie {
  // The Movie class represents a movie object with various properties.
  // It includes methods to parse JSON data into a Movie object.
  // The Movie class is used to represent a movie object with various properties.
  // It includes methods to parse JSON data into a Movie object.

  final int id;
  final String title;
  final String overview;
  final String posterPath;
  final String releaseDate;
  final double rating;

  Movie({
    required this.id,
    required this.title,
    required this.overview,
    required this.posterPath,
    required this.releaseDate,
    required this.rating,
  });

  factory Movie.fromJson(Map<String, dynamic> json) {
    return Movie(
      id: json['id'],
      title: json['title'] ?? 'No Title',
      overview: json['overview'] ?? 'No Overview',
      posterPath:
          json['poster_path'] != null
              ? 'https://image.tmdb.org/t/p/w500${json['poster_path']}'
              : '', // fallback for null poster
      releaseDate: json['release_date'] ?? 'Unknown',
      rating: (json['vote_average'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
