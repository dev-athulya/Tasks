import 'package:task_assment/data/api/movies_apis_provider.dart';
import 'package:task_assment/data/models/movies_model.dart';

class MovieRepository {
  // The MovieRepository class is responsible for managing the data layer of the movie search feature.
  // It interacts with the MovieApiProvider to fetch movie data from the TMDB API.
  final MovieApiProvider _apiProvider = MovieApiProvider();

  Future<List<Movie>> searchMovies(String query, int page) async {
    //  return await _apiProvider.fetchMovies(query, page);

    final response = await _apiProvider.fetchMovies(query, page);
    if (response.isEmpty) {
      throw Exception('No movies found');
    }
    return response;
  }

  Future<List<Movie>> fetchMovies({required int page}) async {
    // Implement the logic to fetch movies for the given page

    return await searchMovies('', page);
  }
}
