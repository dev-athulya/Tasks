import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:task_assment/bloc/moviebloc.dart';
import 'package:task_assment/data/repo/movies_repo.dart';

import 'ui/pages/home_page.dart';

void main() {
  runApp(const MovieApp());
}

class MovieApp extends StatelessWidget {
  const MovieApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final movieRepository = MovieRepository();
    return MaterialApp(
      title: 'Search Movies',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: BlocProvider(
        // Provide the MovieBloc to the widget tree
        create: (_) => MovieBloc(movieRepository),

        // The MovieBloc will be used to manage the state of the movie search feature
        // The MovieRepository will be used to fetch movie data from the API
        // The BlocProvider will allow the MovieBloc to be accessed by the HomePage widget
        child: HomePage(),
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}
